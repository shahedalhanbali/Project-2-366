# Progress Report 1 – Part (a): Fibonacci in MIPS

## Team Members
- Shahed Alhanbali (670025395)
- Cindy Jurado (653416500)
- Qudsia Sultana (657855210)

## Contribution Breakdown
- Shahed Alhanbali: Worked on the iterative logic in MIPS and helped test the output for accuracy.
- Cindy Jurado: Assisted with debugging, wrote the README draft, and helped prepare files for submission.
- Qudsia Sultana: Helped write and test the Fibonacci function in MIPS and contributed to the README instructions.

## GitHub Link
https://github.com/shahedalhanbali/Project-2-366

## Summary
In this progress report, our team implemented the function Fibonacci(n) in MIPS Assembly language using the iterative approach provided in the assignment. The logic is based on the provided Python pseudocode, where we initialize the first two Fibonacci numbers and iteratively compute the nth number.

## How to Run the Program
1. Open the file `fibonacci.asm` in the MARS MIPS Simulator.
2. Set the desired value of `n` by entering it in register `$a0`.
3. Assemble the program (gear icon), then run it (green play button).
4. The result `Fibonacci(n)` will be stored in `$v0`.

## Sample Outputs

| Input (n) | Fibonacci(n)- Decimal |
|-----------|--------------|
| 0         | 0            |
| 1         | 1            |
| 5         | 5            |
| 7         | 13           |
| 10        | 55           |
